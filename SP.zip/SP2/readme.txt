6. phpmyadmin namiesto mysql 
7. pridat zahashovanie hesla