<?php

/* Including the home.php file in the View folder. */
require_once("View\home.php");
