<?php

require_once("..\Model\MyDatabase.class.php");

class Signup
{

    private $email;
    private $pass1;
    private $pass2;

    private $myDB;

    public function __construct($email, $pass1, $pass2)
    {
        $this->email = $email;
        $this->pass1 = $pass1;
        $this->pass2 = $pass2;

        $this->myDB = new MyDatabase();
    }

    public function signupUser()
    {
        if ($this->checkEmptyInput() == false) {
            echo "<script language='javascript'>";
            echo 'alert("Empty input.");';
            echo 'window.location.replace("../View/signup.php");';
            echo "</script>";
        }

        if ($this->checkPassMatch() == false) {

            echo "<script language='javascript'>";
            echo 'alert("Passwords do not match.");';
            echo 'window.location.replace("../View/signup.php");';
            echo "</script>";
        }

        $this->checkUser();
    }

    private function checkEmptyInput()
    {
        if (empty($this->email) || empty($this->pass1) || empty($this->pass2)) {
            $res = false;
        } else {
            $res = true;
        }
        return $res;
    }

    private function checkPassMatch()
    {
        if ($this->pass1 != $this->pass2) {
            $res = false;
        } else {
            $res = true;
        }
        return $res;
    }

    private function checkUser()
    {
        $user = $this->myDB->getUser($this->email, $this->pass1);

        if (!empty($user)) {
            echo "<script language='javascript'>";
            echo 'alert("This user already exist.");';
            echo 'window.location.replace("../View/signup.php");';
            echo "</script>";
        } else {
            $res = $this->myDB->addNewUser($this->email, $this->pass1);

            if ($res) {
                header("Location:../View/login.php");
                exit();
                // dotaz probehl v poradku
                echo "OK: Uživatel byl přidán do databáze.";
                echo "<br><br>";
            } else {
                // dotaz skoncil chybou
                echo "ERROR: Uložení uživatele se nezdařilo.";
                echo "<br><br>";
            }
        }
    }
}
