<?php
if (isset($_POST['submit'])) {

    include("booking.class.php");

    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $day = $_POST['day'];

    /* Preventing XSS. */
    $first_name = htmlspecialchars($first_name);
    $last_name = htmlspecialchars($last_name);
    $email = htmlspecialchars($email);
    $day = htmlspecialchars($day);

    $booking = new Booking($first_name, $last_name, $email, $day);
    $booking->book();

    /* Redirecting the user to the previous page. */
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}
