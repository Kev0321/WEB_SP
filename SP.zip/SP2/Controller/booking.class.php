<?php

require_once("..\Model\MyDatabase.class.php");

class Booking
{

    private $first_name;
    private $last_name;
    private $email;
    private $day;

    private $myDB;

    public function __construct($first_name, $last_name, $email, $day)
    {
        $this->first_name = $first_name;
        $this->last_name = $last_name;
        $this->email = $email;
        $this->day = $day;

        $this->myDB = new MyDatabase();
    }

    public function book()
    {
        if ($this->checkEmptyInput() == false) {
            echo "<script language='javascript'>";
            echo 'alert("Empty input.");';
            echo 'window.location.replace("../View/login.php");';
            echo "</script>";
        }

        $this->myDB->addBooking($this->first_name, $this->last_name, $this->email, $this->day);
    }

    private function checkEmptyInput()
    {
        if (empty($this->first_name) || empty($this->last_name) || empty($this->email) || empty($this->day)) {
            $res = false;
        } else {
            $res = true;
        }
        return $res;
    }
}
