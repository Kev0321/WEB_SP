<?php

require_once("..\Model\MyDatabase.class.php");

class Login
{

    private $email;
    private $pass;

    private $myDB;

    public function __construct($email, $pass)
    {
        $this->email = $email;

        $this->pass = $pass;

        $this->myDB = new MyDatabase();
    }

    public function loginUser()
    {
        if ($this->checkEmptyInput() == false) {
            echo "<script language='javascript'>";
            echo 'alert("Empty input.");';
            echo 'window.location.replace("../View/login.php");';
            echo "</script>";
        }

        $this->checkUser();
    }

    private function checkEmptyInput()
    {
        if (empty($this->email) || empty($this->pass)) {
            $res = false;
        } else {
            $res = true;
        }
        return $res;
    }

    private function checkUser()
    {
        $user = $this->myDB->getUser($this->email, $this->pass);

        if (!empty($user)) {

            if ($user[0]['usertype'] == "customer") {
                // customer page
                header("Location:../View/customer.php");
                exit();
            } elseif ($user[0]['usertype'] == "hairdresser") {
                // hairdresser page
                header("Location:../View/hairdresser.php");
                exit();
            } elseif ($user[0]['usertype'] == "admin") {
                // admin page
                header("Location:../View/admin.php");
                exit();
            }
        } else {
            echo "<script language='javascript'>";
            echo 'alert("We don\'t know you, get lost.");';
            echo 'window.location.replace("../View/signup.php");';
            echo "</script>";
        }
    }
}
