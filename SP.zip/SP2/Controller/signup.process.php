<?php
if (isset($_POST['submit'])) {

    include("signup.class.php");

    $email = $_POST['email'];
    $pass1 = $_POST['password1'];
    $pass2 = $_POST['password2'];

    /* Preventing XSS. */
    $email = htmlspecialchars($email);
    $pass1 = htmlspecialchars($pass1);
    $pass2 = htmlspecialchars($pass2);

    $signup = new Signup($email, $pass1, $pass2);

    $signup->signupUser();

}
