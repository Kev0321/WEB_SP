<?php
if (isset($_POST['submit'])) {

    include("login.class.php");

    $email = $_POST['email'];
    $pass = $_POST['password'];

    /* Preventing XSS. */
    $email = htmlspecialchars($email);
    $pass = htmlspecialchars($pass);

    $signup = new Login($email, $pass);

    $signup->loginUser();
}
