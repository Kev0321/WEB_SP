<?php

/* A class that is used to connect to the database. */
class MyDatabase
{

    /* A private variable that is used to store the connection to the database. */
    private $pdo;

    /* Setting the database connection variables. */
    private $dbhost = "localhost";
    private $dbname = "web";
    private $dbuser = "root";
    private $dbpass = "";

    /**
     * MyDatabase constructor.
     */
    public function __construct()
    {
        /* Creating a new PDO object. */
        $this->pdo = new PDO("mysql:host={$this->dbhost};dbname={$this->dbname}", $this->dbuser, $this->dbpass);
        /* Setting the character encoding to UTF-8. */
        $this->pdo->exec("set names utf8");
        /* Setting the error mode to exception. */
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    /**
     * It inserts a new row into the table
     * 
     * @param string first_name
     * @param string last_name 
     * @param string email varchar(255)
     * @param string day date
     */
    public function addBooking(string $first_name, string $last_name, string $email, string $day)
    {
        $table_bookings = "bookings";

        /* Preventing SQL injection. */
        $q = "INSERT INTO $table_bookings (first_name, last_name, email, day) VALUES (:first_name, :last_name, :email, :day);";
        $res = $this->pdo->prepare($q);
        $res->bindValue(":first_name", $first_name);
        $res->bindValue(":last_name", $last_name);
        $res->bindValue(":email", $email);
        $res->bindValue(":day", $day);

        if ($res->execute()) {
            // dotaz probehl v poradku
            echo "OK: Uživatel byl přidán do databáze.";
            echo "<br><br>";
        } else {
            // dotaz skoncil chybou
            echo "ERROR: Uložení uživatele se nezdařilo.";
            echo "<br><br>";
        }
    }



    /* A function that is used to select data from the database. */
    public function selectFromTable(string $tableName, string $whereStatement = ""): array
    {
        /* Preventing SQL injection. */
        $q = "SELECT * FROM " . $tableName
            . (($whereStatement == "") ? "" : " WHERE $whereStatement");
        $stmt = $this->pdo->prepare($q);
        $stmt->execute();

        $res = $stmt->fetchAll();

        return $res;
    }

    /* Getting all the users from the database. */
    public function getAllUsers()
    {
        $table_users = "users";

        /* Selecting all the users from the table. */
        $users = $this->selectFromTable($table_users, "");

        /* Returning the array of users. */
        return $users;
    }

    /* Getting all the bookings from the database. */
    public function getAllBookings()
    {
        $table_bookings = "bookings";

        /* Selecting all the users from the table. */
        $users = $this->selectFromTable($table_bookings, "");

        /* Returning the array of users. */
        return $users;
    }

    /* Getting the user from the database. */
    public function getUser($email, $pass)
    {
        /* A variable that is used to store the name of the table. */
        $table_users = "users";

        /* A where statement that is used to select the user from the database. */
        $whereStatement = "email = '$email' AND password = '$pass'";

        /* Selecting the user from the database. */
        $user = $this->selectFromTable($table_users, $whereStatement);

        return $user;
    }

    /* Adding a new user to the database. */
    public function addNewUser($email, $pass)
    {
        $table_users = "users";

        /* Preventing SQL injection. */
        $q = "INSERT INTO $table_users (email, password) VALUES (:email, :password);";
        $res = $this->pdo->prepare($q);
        $res->bindValue(":email", $email);
        $res->bindValue(":password", $pass);

        /* Returning the result of the query. */
        return $res->execute();
    }

    /* It deletes a row from the table. */
    public function deleteFromTable(string $tableName, string $whereStatement): bool
    {
        /* Preventing SQL injection. */
        $q = "DELETE FROM $tableName WHERE $whereStatement";
        $res = $this->pdo->prepare($q);
        $res->execute();

        return $res;
    }
}
