create database web;

use web;

DROP TABLE IF EXISTS `customers` ;

CREATE TABLE IF NOT EXISTS `customers` (
  `first_name` VARCHAR(45) NULL,
  `last_name` VARCHAR(45) NULL,
  `email` VARCHAR(45) NULL,
  `day` DATE NULL);

select * from customers;

delete from customers where first_name = "test";

DROP TABLE IF EXISTS `admin` ;

CREATE TABLE IF NOT EXISTS `admin` (
  `email` VARCHAR(45) NULL,
  `password` VARCHAR(45) NULL,);

DROP TABLE IF EXISTS `hairdressers` ;

CREATE TABLE IF NOT EXISTS `hairdressers` (
  `email` VARCHAR(45) NULL,
  `password` VARCHAR(45) NULL,);


DROP TABLE IF EXISTS `users` ;


CREATE TABLE IF NOT EXISTS `users` (
  `id_users` INT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(45) NULL,
  `password` VARCHAR(45) NULL,
  `usertype` VARCHAR(45) NULL,
  PRIMARY KEY (`id_users`));


INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'admin@email.com', 'admin', 'admin');
INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'peterstrihac@email.com', 'somdobry', 'hairdresser');
INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'mimavar@email.com', 'mimavar', 'hairdresser');
INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'zuzanaostra@email.com', 'zuzanka', 'hairdresser');

INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'janonovy@email.com', 'janonovy', 'customer');
INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'martinstary@email.com', 'martinstary', 'customer');
INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'hanamon@email.com', 'hanamon', 'customer');
INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'sofiavar@email.com', 'sofiavar', 'customer');
INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'kikapako@email.com', 'kikapako', 'customer');
INSERT INTO `users` (`id_users`, `email`, `password`, `usertype`) VALUES (NULL, 'kevinvar@email.com', 'kevinvar', 'customer');

COMMIT;


select * from users;
