<!DOCTYPE html>
<html lang="en">

<head>
    <!-- HEAD -->
    <?php require("Include/head.inc.php") ?>
</head>

<body id="home" data-bs-spy="scroll" data-bs-target=".navbar">

    <!-- HEADER -->
    <header>
        <!-- NAVBAR -->
        <?php include("Include/header.inc.php") ?>
    </header>

    <!-- MAIN -->
    <main>
        <!-- HERO -->
        <?php include("Include/hero.inc.php") ?>

        <!-- ABOUT -->
        <?php include("Include/about.inc.php") ?>

        <!-- SERVICES -->
        <?php include("Include/services.inc.php") ?>

        <!-- REVIEWS -->
        <?php include("Include/reviews.inc.php") ?>

        <!-- BOOKING -->
        <?php include("Include/booking.inc.php") ?>

    </main>

    <!-- FOOTER -->
    <footer>
        <!-- TOP -->
        <!-- CONTACT -->
        <?php include("Include/footer-top.inc.php") ?>
        <!-- BOTTOM -->
        <?php include("Include/footer-bottom.inc.php") ?>
    </footer>


    <!--  Javascript  -->
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
    <!-- Jquery -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <!-- Popper -->
    <script src="node_modules/popper.js/dist/popper.js"></script>

    <script>
        const dateInput = document.getElementById('day');

        dateInput.value = formatDate();

        console.log(formatDate());

        function padTo2Digits(num) {
            return num.toString().padStart(2, '0');
        }

        function formatDate(date = new Date()) {
            return [
                date.getFullYear(),
                padTo2Digits(date.getMonth() + 1),
                padTo2Digits(date.getDate()),
            ].join('-');
        }
    </script>

</body>

</html>