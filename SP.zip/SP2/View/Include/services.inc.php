<section id="services">
            <div class="container text-center">
                <div class="row">
                    <div class="col-12 intro">
                        <h1>What do we provide?</h1>
                        <hr>
                    </div>
                </div>
                <div class="row">

                    <div class="col-lg-4 col-md-6">

                        <div class="service">
                            <img src="Images/img8.jpg" class="img" />
                            <div class="content">
                                <h3>COLORING</h3>
                                <p>
                                    From basic cover-up of your little gray imperfections to more complicated techniques
                                    like highlights, balayage or ombre.
                                </p>
                                <hr>
                                <a href="#contact" class="link-more">Know more
                                    <i class="fa fa-solid fa-arrow-right icon"></i>
                                </a>
                            </div>
                        </div>

                    </div>

                    <div class="col-lg-4 col-md-6">

                        <div class="service">
                            <img src="Images/img14.jpg" class="img" />
                            <div class="content">
                                <h3>CUTTING</h3>
                                <p>
                                    There is nothing that can make you shine more than a fresh and stylish haircut.
                                    <br>
                                    <br>
                                </p>
                                <hr>
                                <a href="#contact" class="link-more">Know more <i class="fa fa-solid fa-arrow-right icon"></i>
                                </a>
                            </div>
                        </div>

                    </div>

                    <div class="col-lg-4 col-md-6">

                        <div class="service">
                            <img src="Images/img16.jpg" class="img" />
                            <div class="content">
                                <h3>STYLING</h3>
                                <p>
                                    Everything from family celebrations to fancy wedddings. According to your
                                    preferences and imagination, we can make miracles.
                                </p>
                                <hr>
                                <a href="#contact" class="link-more">Know more <i class="fa fa-solid fa-arrow-right icon"></i>
                                </a>
                            </div>
                        </div>

                    </div>


                </div>

                <div class="cta-btns">
                    <a href="#booking" class="btn btn-outline-primary me-sm-2">Book now</a>
                    <a href="#contact" class="btn btn-outline-primary ms-sm-2">Contact us</a>
                </div>

            </div>
        </section>