<section id="booking">
    <div class="container">
        <div class="row py-5">
            <div class="col-lg-8 mx-auto">
                <!-- FORM -->
                <form class="row" action="Controller\booking.process.php" method="POST" id="input_form">
                    <!-- <form class="row" id="input_form"> -->
                    <div class="col-12 mb-4 text-center">
                        <h1>Book now</h1>
                        <hr>
                    </div>

                    <div class="col-12">
                        <div class="form-group col-13">
                            <h5>First name:</h5>
                            <input type="text" name="first_name" id="first_name" class="form-control" placeholder="First name" required>
                        </div>

                        <div class="form-group col-13">
                            <h5>Last name:</h5>
                            <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last name" required>
                        </div>


                        <div class="form-group col-13">
                            <h5>E-mail:</h5>
                            <input type="email" name="email" id="email" class="form-control" placeholder="E-mail adress" required>
                        </div>

                        <div class="form-group col-13">
                            <h5>Appointment date:</h5>
                            <input type="date" name="day" id="day" class="form-control" placeholder="DD/MM/YYYY" min="2023-01-01" required>
                        </div>

                        <div class="form-group col-13 mt-4 text-center">
                            <button type="submit" name="submit" id="submit" class="btn btn-outline-primary">Submit</button>
                        </div>

                        <div id="success">

                        </div>

                    </div>


                </form>
            </div>
        </div>
    </div>
</section>