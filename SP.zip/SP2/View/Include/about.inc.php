<section id="about">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5">
                <img src="Images/img13.jpg" alt="" />
            </div>
            <div class="col-lg-4 offset-lg-1">
                <h1>About FreshHaircut</h1>
                <p>
                    We are a group of young, very promising haidressers who fullfill their dreams by making your
                    hairstyle dreams come true.
                </p>
            </div>
        </div>
    </div>
</section>