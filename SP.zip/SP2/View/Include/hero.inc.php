<section id="hero">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <h1 class="display-4">Let your hair shine.</h1>
                        <p>
                            Choose the first class service and treat your hair <br> with the premium quality products.
                            <br> Let your inner goddess shine!
                        </p>
                        <a href="#contact" class="btn btn-outline-primary">Contact us</a>
                    </div>
                </div>
            </div>
        </section>