<div class="foooter-top">
    <div class="container">
        <div class="row gy-5">
            <div class="col-lg-5 mx-auto">
                <h4 class="mb-3">Working hours</h4>
                <hr>
                <div>
                    <h6>Monday-Friday</h6>
                    <p>8:00 - 16:00</p>
                </div>

                <div>
                    <h6>Weekends</h6>
                    <p>Closed</p>
                </div>

            </div>

            <div class="col-lg-5" id="contact">
                <h4>Contact</h4>
                <hr>
                <p>
                    <i class="fa fa-solid fa-location-arrow"></i>
                    <span> Hlavná 1</span>
                </p>
                <p>
                    <i class="fa fa-solid fa-envelope"></i>
                    <span> FreshHaircut@email.com</span>
                </p>
                <p>
                    <i class="fa fa-solid fa-phone"></i>
                    <span> 725 820 779</span>
                </p>

                <div class="social-links">
                    <a href="https://www.facebook.com/MimaVarchol"><i class="fa fa-brands fa-facebook"></i></a>
                    <a href="https://www.instagram.com/cesta.za.snom/"><i class="fa fa-brands fa-instagram"></i></a>
                </div>
            </div>


        </div>
    </div>
</div>