<div class="footer-bottom">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-auto">
                <p>Copyrights @FreshHaircut</p>
            </div>
            <div class="col-auto">
                <p>Design by kevinvar</p>
            </div>
        </div>
    </div>
</div>