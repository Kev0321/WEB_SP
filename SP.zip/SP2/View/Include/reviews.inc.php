<section id="reviews">
            <div class="container">

                <div class="row">
                    <div class="col-12 intro text-center">
                        <h1>What do our customers say?</h1>
                    </div>

                    <div class="row gy-4">
                        <hr>

                        <div class="col-lg-4 col-md-6">
                            <div class="review">
                                <div class="d-flex">
                                    <div class="icon"><i class="fa fa-solid fa-star"></i></div>
                                    <div class="ms-3">
                                        <h5>Jano Nový</h5>
                                        <small>@JanoNovy</small>
                                        <hr>
                                        <p class="mb-4">Great hairstyles even for men.</p>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-4 col-md-6">
                            <div class="review">
                                <div class="d-flex">
                                    <div class="icon"><i class="fa fa-solid fa-star"></i></div>
                                    <div class="ms-3">
                                        <h5>Kristina Pataky</h5>
                                        <small>@KikaPako</small>
                                        <hr>
                                        <p class="mb-4">Never felt more beautiful.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="review">
                                <div class="d-flex">
                                    <div class="icon"><i class="fa fa-solid fa-star"></i></div>
                                    <div class="ms-3">
                                        <h5>Jakub Potrik</h5>
                                        <small>@JakubPotrik</small>
                                        <hr>
                                        <p class="mb-4">Great quality for reasonable price.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="review">
                                <div class="d-flex">
                                    <div class="icon"><i class="fa fa-solid fa-star"></i></div>
                                    <div class="ms-3">
                                        <h5>Monika Unicorn</h5>
                                        <small>@MonikaUni</small>
                                        <hr>
                                        <p class="mb-4">Nice staff and pretty salon :)</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="review">
                                <div class="d-flex">
                                    <div class="icon"><i class="fa fa-solid fa-star"></i></div>
                                    <div class="ms-3">
                                        <h5>Kevin Alone</h5>
                                        <small>@KevinAlone</small>
                                        <hr>
                                        <p class="mb-4">Cool service.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="review">
                                <div class="d-flex">
                                    <div class="icon"><i class="fa fa-solid fa-star"></i></div>
                                    <div class="ms-3">
                                        <h5>Karl Karczi</h5>
                                        <small>@KarlKarczi</small>
                                        <hr>
                                        <p class="mb-4">Very satisfied with the result.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>
                    </div>


                </div>

                <div class="cta-btns text-center">
                    <a href="#booking" class="btn btn-outline-primary me-sm-2 my-2">Book now</a>
                    <a href="#contact" class="btn btn-outline-primary ms-sm-2">Contact us</a>
                </div>

            </div>
        </section>