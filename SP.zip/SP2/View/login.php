<!DOCTYPE html>

<html>

<head>
    <?php include("Include/head.inc.php") ?>
    <!-- Css -->
    <link rel="stylesheet" href="../Css/login.css" />
</head>

<body>

    <!-- HEADER -->
    <header>
        <!-- NAVBAR -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <a class="navbar-brand" href="../index.php">FreshHaircut</a>
        </nav>
    </header>

    <main>

        <div class="box">
            <form autocomplete="off" action="../Controller/login.process.php" method="POST">
                <h2>Login</h2>
                <hr>
                <div class="inputBox">
                    <input type="text" name="email" required="required" />
                    <span>E-mail</span>
                    <i></i>
                </div>

                <div class="inputBox">
                    <input type="password" name="password" required="required" />
                    <span>Password</span>
                    <i></i>
                </div>

                <div class="links">
                    <a href="signup.php">Signup</a>
                </div>

                <input type="submit" name="submit" value="Login" />

            </form>
        </div>

    </main>

    <!-- FOOTER -->
    <footer>
        <!-- BOTTOM -->
        <?php include("Include/footer-bottom.inc.php") ?>
    </footer>



    <!--  Javascript  -->
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
    <!-- Jquery -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <!-- Popper -->
    <script src="node_modules/popper.js/dist/popper.js"></script>
</body>

</html>