<?php
require_once("../Model/MyDatabase.class.php");
$myDB = new MyDatabase();
?>

<!DOCTYPE html>

<html>

<head>
    <!-- HEAD -->
    <?php include("Include/head.inc.php") ?>
    <link rel="stylesheet" href="../Css/style2.css">
</head>

<body>

    <!-- HEADER -->
    <header>
        <!-- NAVBAR -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="../index.php">FreshHaircut</a>
            </div>
        </nav>
    </header>

    <main>
        <div class="container">
            <h1>Welcome Customer</h1>
            <hr>
            <?php

            $bookings = $myDB->getAllBookings();
            ?>

            <h2>List of bookings</h2>
            <table border="1">
                <tr>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Date</th>
                </tr>
                <?php
                foreach ($bookings as $b) {
                    if ($b['email'] == "kevinvar@email.com") {

                        echo "<tr>
                        <td>$b[first_name]</td>
                        <td>$b[last_name]</td>
                        <td>$b[day]</td>
                        </tr>";
                    }
                }
                ?>
            </table>

        </div>
    </main>

    <!-- FOOTER -->
    <footer">
        <!-- BOTTOM -->
        <?php include("Include/footer-bottom.inc.php") ?>
        </footer>

        <!--  Javascript  -->
        <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
        <!-- Jquery -->
        <script src="node_modules/jquery/dist/jquery.js"></script>
        <!-- Popper -->
        <script src="node_modules/popper.js/dist/popper.js"></script>
</body>

</html>