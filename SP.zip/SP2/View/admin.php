<?php
require_once("../Model/MyDatabase.class.php");
$myDB = new MyDatabase();
?>

<!DOCTYPE html>

<html>

<head>
    <!-- HEAD -->
    <?php include("Include/head.inc.php") ?>
    <link rel="stylesheet" href="../Css/style2.css">
</head>

<body>

    <!-- HEADER -->
    <header>
        <!-- NAVBAR -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="../index.php">FreshHaircut</a>
            </div>
        </nav>
    </header>

    <main>
        <div class="container">
            <h1>Welcome admin</h1>
            <hr>
            <?php

            $table_users = "users";

            // zpracovani formulare pro smazani uzivatele
            if (!empty($_POST['id_users'])) {
                // smazu daneho uzivatele z databaze
                $res = $myDB->deleteFromTable($table_users, "id_users='$_POST[id_users]'");
                // vysledek mazani
                if ($res) {
                    echo "<script language='javascript'>";
                    echo 'alert("OK: Uživatel byl smazán z databáze.");';
                    echo 'window.location.replace("../View/admin.php");';
                    echo "</script>";
                } else {
                    echo "<script language='javascript'>";
                    echo 'alert("ERROR: Smazání uživatele se nezdařilo.");';
                    echo 'window.location.replace("../View/admin.php");';
                    echo "</script>";
                }
            }

            $users = $myDB->getAllUsers();
            ?>

            <h2>List of users</h2>
            <table border="1">
                <tr>
                    <th>ID</th>
                    <th>E-mail</th>
                    <th>Password</th>
                    <th>User type</th>
                    <th>Action</th>
                </tr>
                <?php
                foreach ($users as $u) {
                    echo "<tr>
                <td>$u[id_users]</td>
                <td>$u[email]</td>
                <td>$u[password]</td>
                <td>$u[usertype]</td><td>"
                        . (($u['usertype'] == "admin") ? "" :
                            "<form action='' method='POST'>
                    <input type='hidden' name='id_users' value='$u[id_users]'>
                    <input type='hidden' name='usertype' value='$u[usertype]'>
                    <input type='submit' name='potvrzeni' value='Smazat'>
                    </form>"

                        ) . "</td></tr>";
                }
                ?>
            </table>

        </div>
    </main>

    <!-- FOOTER -->
    <footer">
        <!-- BOTTOM -->
        <?php include("Include/footer-bottom.inc.php") ?>
        </footer>

        <!--  Javascript  -->
        <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
        <!-- Jquery -->
        <script src="node_modules/jquery/dist/jquery.js"></script>
        <!-- Popper -->
        <script src="node_modules/popper.js/dist/popper.js"></script>
</body>

</html>